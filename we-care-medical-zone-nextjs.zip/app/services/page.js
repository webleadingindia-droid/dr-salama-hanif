import Link from "next/link";
import PageHero from "@/components/PageHero";
import { SERVICES_FULL, OFFER_BAND } from "@/lib/data";

export const metadata = {
  title: "Women's Health Services | Dr. Salama Hanif",
  description:
    "Explore all women's health services at We Care Medical Zone – PCOD, infertility, pregnancy, fibroid, menopause and more by Dr. Salama Hanif in Raebareli.",
};

export default function ServicesPage() {
  return (
    <>
      <PageHero
        current="Services"
        title="Our Services"
        subtitle="Comprehensive women's health services under one roof — from routine care to specialized treatments."
      />

      {/* SERVICES GRID */}
      <section className="section-pad">
        <div className="container">
          <div className="row g-4">
            {SERVICES_FULL.map((svc) => (
              <div className="col-md-6 col-lg-4 fade-up" key={svc.title}>
                <div className="card-service">
                  <div className="service-icon"><i className={`bi ${svc.icon}`} /></div>
                  <h5>{svc.title}</h5>
                  <p>{svc.desc}</p>
                  <Link href={svc.link || "/treatments"} className="read-more mt-3 d-inline-flex">
                    Learn More <i className="bi bi-arrow-right" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* OFFER BAND */}
      <section className="section-pad-sm" style={{ background: "var(--grey-bg)" }}>
        <div className="container">
          <div className="row g-4 text-center">
            {OFFER_BAND.map((offer) => (
              <div className="col-md-4 fade-up" key={offer.title}>
                <div className={`offer-stat offer-stat-${offer.variant}`}>
                  <div
                    className="offer-stat-num"
                    style={{ color: offer.variant === "pink" ? "#fff" : offer.num === "30%" ? "var(--blue)" : "var(--pink)" }}
                  >
                    {offer.num}
                  </div>
                  <strong style={offer.variant === "pink" ? { color: "#fff" } : undefined}>{offer.title}</strong>
                  <p
                    className={offer.variant === "pink" ? undefined : "text-muted"}
                    style={{
                      fontSize: ".84rem",
                      marginTop: 6,
                      marginBottom: 0,
                      color: offer.variant === "pink" ? "rgba(255,255,255,.8)" : undefined,
                    }}
                  >
                    {offer.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

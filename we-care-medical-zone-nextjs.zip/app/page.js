import Link from "next/link";
import Counter from "@/components/Counter";
import {
  CLINIC,
  HERO_STATS,
  ABOUT_STRIP_HIGHLIGHTS,
  ABOUT_STRIP_STATS,
  HOME_SERVICES,
  WHY_CHOOSE_US,
  DISCOUNT_CHIPS,
  AWARENESS_CARDS,
  TESTIMONIALS,
  GALLERY_PREVIEW,
} from "@/lib/data";

export default function HomePage() {
  return (
    <>
      {/* HERO */}
      <section className="hero">
        <div className="container position-relative" style={{ zIndex: 2 }}>
          <div className="row align-items-center gy-5">
            <div className="col-lg-6">
              <div className="hero-badge">
                <i className="bi bi-shield-check-fill" />
                Trusted Ayurvedic Women&apos;s Health Care
              </div>
              <h1 className="hero-title">
                Expert Ayurvedic Care for
                <br />
                <span className="text-pink">Women&apos;s Health</span>
                <br />
                &amp; Wellness
              </h1>
              <p className="hero-tagline">
                Dedicated to Hope, Healing and Recovery — {CLINIC.doctor} brings compassionate,
                expert Ayurvedic gynecological care to Raebareli.
              </p>
              <div className="d-flex flex-wrap gap-3">
                <a href="#" data-bs-toggle="modal" data-bs-target="#apptModal" className="btn-pink btn">
                  <i className="bi bi-calendar-plus me-2" />
                  Book Free Consultation
                </a>
                <Link href="/about" className="btn-outline-pink btn">
                  <i className="bi bi-person-circle me-2" />
                  Meet the Doctor
                </Link>
              </div>
              <div className="hero-stats">
                {HERO_STATS.map((stat) => (
                  <div className="hero-stat" key={stat.label}>
                    <Counter target={stat.count} suffix={stat.suffix} />
                    <span>{stat.label}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="col-lg-6">
              <div className="hero-img-wrap">
                <div className="hero-img-card">
                  <div className="hero-img-placeholder">
                    <img
                      src="https://plain-apac-prod-public.komododecks.com/202611/16/VKuscGrJVlV1QXuNCOud/image.png"
                      alt="Ayurvedic treatment for women's wellness"
                    />
                  </div>
                </div>
                <div className="hero-float-card card-1">
                  <i className="bi bi-check-circle-fill text-success fs-3" />
                  <div>
                    <strong>BAMS + MD (Ayurveda)</strong>
                    <small>Certified Ayurvedic Specialist</small>
                  </div>
                </div>
                <div className="hero-float-card card-2">
                  <i className="bi bi-clock-fill" style={{ color: "var(--blue)", fontSize: "1.4rem" }} />
                  <div>
                    <strong>Mon–Thu, Sat</strong>
                    <small>9AM–12PM | 6PM–9PM</small>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* OFFER STRIP */}
      <div className="offer-strip">
        <div className="container-fluid">
          <div className="offer-strip-inner" id="offerStrip">
            {[0, 1].map((i) => (
              <span className="d-contents" key={i} style={{ display: "contents" }}>
                <span className="offer-chip"><i className="bi bi-gift-fill" /> 50% OFF on First Ayurvedic Consultation</span>
                <span className="offer-chip"><i className="bi bi-capsule-pill" /> 15% Discount on Ayurvedic Medicines</span>
                <span className="offer-chip"><i className="bi bi-droplet-fill" /> 30% OFF on Lab &amp; Prakriti Tests</span>
                <span className="offer-chip"><i className="bi bi-heart-fill" /> Expert Ayurvedic Women&apos;s Health Care</span>
                <span className="offer-chip"><i className="bi bi-telephone-fill" /> Call: {CLINIC.phone}</span>
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* ABOUT CLINIC STRIP */}
      <section className="section-pad bg-grey">
        <div className="container">
          <div className="row align-items-center gy-5">
            <div className="col-lg-6 fade-up">
              <div className="section-label">About We Care Medical Zone</div>
              <div className="divider-pink" />
              <h2 className="section-title mb-3">
                Compassionate Ayurvedic Care,
                <br />
                Modern Healing
              </h2>
              <p className="text-muted mb-4">
                We Care Medical Zone is Raebareli&apos;s trusted destination for women&apos;s
                health. Led by {CLINIC.doctor}, a highly experienced Ayurvedic Gynecologist &amp;
                Obstetrician, we provide personalized, evidence-based Ayurvedic treatment in a
                warm and supportive environment.
              </p>
              <div className="row g-3 mb-4">
                {ABOUT_STRIP_HIGHLIGHTS.map((item, i) => (
                  <div className="col-6" key={item}>
                    <div className="d-flex align-items-center gap-2">
                      <i className="bi bi-check-circle-fill text-pink" />
                      <span className={i === 0 ? "fw-500" : undefined} style={{ fontSize: ".9rem" }}>
                        {item}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <Link href="/about" className="btn-pink btn">
                Learn More <i className="bi bi-arrow-right ms-2" />
              </Link>
            </div>
            <div className="col-lg-6 fade-up">
              <img
                src="https://ayurhealing.net/wp-content/uploads/2025/08/ayurvedic-treatment-for-womens-wellness.jpg"
                className="img-fluid mb-3 rounded-2xl"
                alt="We Care Medical Zone clinic"
              />
              <div className="row g-3">
                {ABOUT_STRIP_STATS.map((s) => (
                  <div className="col-4" key={s.label}>
                    <div className={`stat-box stat-box-${s.variant}`}>
                      <i className={`bi ${s.icon}`} />
                      <Counter target={s.count} suffix={s.suffix} />
                      <div className="stat-box-label">{s.label}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="section-pad">
        <div className="container">
          <div className="section-head text-center fade-up">
            <div className="section-label">Our Ayurvedic Services</div>
            <div className="divider-pink mx-auto" />
            <h2 className="section-title">Comprehensive Ayurvedic Women&apos;s Health Services</h2>
            <p className="section-sub mx-auto mt-2">
              From routine Ayurvedic check-ups to specialized treatments — we cover every aspect
              of women&apos;s health naturally.
            </p>
          </div>
          <div className="row g-4">
            {HOME_SERVICES.map((svc) => (
              <div className="col-md-6 col-lg-4 fade-up" key={svc.title}>
                <div className="card-service">
                  <div className="service-img">
                    <img src={svc.img} className="img-fluid mb-3 rounded-xl" alt={svc.title} />
                  </div>
                  <h5>{svc.title}</h5>
                  <p>{svc.desc}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-5">
            <Link href="/services" className="btn-pink btn">
              View All Services <i className="bi bi-arrow-right ms-2" />
            </Link>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="section-pad bg-grey">
        <div className="container">
          <div className="section-head text-center fade-up">
            <div className="section-label">Why Choose Us</div>
            <div className="divider-pink mx-auto" />
            <h2 className="section-title">The We Care Ayurvedic Difference</h2>
          </div>
          <div className="row g-4">
            {WHY_CHOOSE_US.map((item) => (
              <div className="col-md-6 col-lg-3 fade-up" key={item.title}>
                <div className="why-card">
                  <div className="why-icon"><i className={`bi ${item.icon}`} /></div>
                  <h5 style={{ fontSize: "1rem", fontFamily: "'DM Sans',sans-serif", fontWeight: 600, marginBottom: 10 }}>
                    {item.title}
                  </h5>
                  <p className="text-muted" style={{ fontSize: ".87rem" }}>{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* DISCOUNT OFFERS */}
      <section className="section-pad">
        <div className="container">
          <div className="cta-banner fade-up">
            <div className="row align-items-center gy-4">
              <div className="col-lg-7" style={{ position: "relative", zIndex: 2 }}>
                <div className="section-label" style={{ color: "rgba(255,255,255,.8)" }}>
                  Exclusive Ayurvedic Offers
                </div>
                <h2 style={{ color: "#fff", fontSize: "clamp(1.6rem,3vw,2.4rem)", marginBottom: 16 }}>
                  Special Discounts for
                  <br />
                  New Patients
                </h2>
                <div className="row g-3">
                  {DISCOUNT_CHIPS.map((chip) => (
                    <div className="col-sm-4" key={chip.label}>
                      <div className="discount-chip">
                        <div className="discount-chip-num">{chip.num}</div>
                        <div className="discount-chip-label">{chip.label}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="col-lg-5 text-lg-end" style={{ position: "relative", zIndex: 2 }}>
                <a href="#" data-bs-toggle="modal" data-bs-target="#apptModal" className="btn-white btn btn-lg">
                  <i className="bi bi-calendar-plus me-2" />
                  Claim Your Discount
                </a>
                <p style={{ color: "rgba(255,255,255,.7)", fontSize: ".82rem", marginTop: 12 }}>
                  *Valid for new patients only. T&amp;C apply.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* WOMEN'S HEALTH AWARENESS */}
      <section className="section-pad-sm bg-grey">
        <div className="container">
          <div className="section-head text-center fade-up">
            <div className="section-label">Ayurvedic Women&apos;s Health Awareness</div>
            <div className="divider-pink mx-auto" />
            <h2 className="section-title">Know Your Health Through Ayurveda</h2>
          </div>
          <div className="row g-4">
            {AWARENESS_CARDS.map((card) => (
              <div className="col-md-4 fade-up" key={card.title}>
                <div className="awareness-card">
                  <div className={`awareness-icon ${card.variant}`}>
                    <i className={`bi ${card.icon}`} />
                  </div>
                  <div>
                    <h6 style={{ fontWeight: 600, marginBottom: 8 }}>{card.title}</h6>
                    <p className="text-muted" style={{ fontSize: ".85rem", margin: 0 }}>{card.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="section-pad">
        <div className="container">
          <div className="section-head text-center fade-up">
            <div className="section-label">Patient Stories</div>
            <div className="divider-pink mx-auto" />
            <h2 className="section-title">What Our Patients Say About Ayurvedic Care</h2>
          </div>
          <div className="row g-4">
            {TESTIMONIALS.map((t) => (
              <div className="col-md-4 fade-up" key={t.name}>
                <div className="testimonial-card">
                  <div className="stars mb-2">
                    {Array.from({ length: Math.floor(t.stars) }).map((_, i) => (
                      <i className="bi bi-star-fill" key={i} />
                    ))}
                    {t.stars % 1 !== 0 && <i className="bi bi-star-half" />}
                  </div>
                  <div className="quote-icon">&quot;</div>
                  <p className="text-muted" style={{ fontSize: ".9rem", marginBottom: 20 }}>{t.quote}</p>
                  <div className="d-flex align-items-center gap-3">
                    <div className="reviewer-avatar" style={{ background: t.avatarGradient }}>{t.avatar}</div>
                    <div>
                      <strong style={{ fontSize: ".92rem" }}>{t.name}</strong>
                      <div className="text-muted" style={{ fontSize: ".78rem" }}>{t.role}</div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* GALLERY PREVIEW */}
      <section className="section-pad-sm bg-grey">
        <div className="container">
          <div className="section-head text-center fade-up">
            <div className="section-label">Our Ayurvedic Clinic</div>
            <div className="divider-pink mx-auto" />
            <h2 className="section-title">Clinic Gallery</h2>
          </div>
          <div className="row g-3">
            {GALLERY_PREVIEW.map((item) => (
              <div className="col-6 col-md-3 fade-up" key={item.label}>
                <div className="gallery-item">
                  <div className="gallery-item-inner preview">
                    <i className={`bi ${item.icon}`} />
                    <small className="text-muted">{item.label}</small>
                  </div>
                  <div className="gallery-overlay"><i className="bi bi-zoom-in" /></div>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-4">
            <Link href="/gallery" className="btn-outline-pink btn">
              View Full Gallery <i className="bi bi-arrow-right ms-2" />
            </Link>
          </div>
        </div>
      </section>

      {/* APPOINTMENT CTA */}
      <section className="section-pad">
        <div className="container">
          <div className="row align-items-center gy-4 p-4 p-md-5 rounded-2xl cta-soft-banner">
            <div className="col-lg-7 fade-up">
              <h2 style={{ fontSize: "clamp(1.5rem,3vw,2.2rem)", marginBottom: 10 }}>
                Ready to Experience Ayurvedic Healing?
              </h2>
              <p className="text-muted mb-0">
                Schedule your Ayurvedic consultation today and get 50% off on your first visit
                with {CLINIC.doctor}.
              </p>
            </div>
            <div className="col-lg-5 text-lg-end d-flex flex-wrap gap-3 justify-content-lg-end fade-up">
              <a href="#" data-bs-toggle="modal" data-bs-target="#apptModal" className="btn-pink btn btn-lg">
                <i className="bi bi-calendar-plus me-2" />
                Book Ayurvedic Appointment
              </a>
              <a href={`tel:${CLINIC.phone}`} className="btn-outline-pink btn btn-lg">
                <i className="bi bi-telephone me-2" />
                Call Now
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* CONTACT SECTION */}
      <section className="section-pad-sm bg-grey">
        <div className="container">
          <div className="section-head text-center fade-up">
            <div className="section-label">Visit Us</div>
            <div className="divider-pink mx-auto" />
            <h2 className="section-title">Find Us in Raebareli</h2>
          </div>
          <div className="row g-4">
            <div className="col-lg-5 fade-up">
              <div className="contact-card h-100">
                <h5 style={{ marginBottom: 6 }}>We Care Medical Zone</h5>
                <p className="text-muted" style={{ fontSize: ".85rem", marginBottom: 20 }}>
                  {CLINIC.doctor} – Ayurvedic Gynecologist &amp; Obstetrician
                </p>
                <div className="contact-info-item">
                  <div className="contact-icon"><i className="bi bi-geo-alt-fill" /></div>
                  <div>
                    <strong style={{ fontSize: ".88rem" }}>Address</strong>
                    <p className="text-muted mb-0" style={{ fontSize: ".84rem" }}>{CLINIC.address}</p>
                  </div>
                </div>
                <div className="contact-info-item">
                  <div className="contact-icon"><i className="bi bi-telephone-fill" /></div>
                  <div>
                    <strong style={{ fontSize: ".88rem" }}>Phone</strong>
                    <p className="text-muted mb-0" style={{ fontSize: ".84rem" }}>
                      <a href={`tel:${CLINIC.phone}`} className="text-pink fw-600">{CLINIC.phoneDisplay}</a>
                    </p>
                  </div>
                </div>
                <div className="contact-info-item">
                  <div className="contact-icon"><i className="bi bi-clock-fill" /></div>
                  <div>
                    <strong style={{ fontSize: ".88rem" }}>Clinic Timings</strong>
                    <div className="mt-2">
                      <div className="timing-row"><span>Mon – Sat</span><span><i className="bi bi-sun me-1 text-warning" />10:00AM – 1:30 PM</span></div>
                      <div className="timing-row"><span>Mon – Sat</span><span><i className="bi bi-moon-stars me-1 text-pink" />4:30PM – 9:00 PM</span></div>
                      <div className="timing-row"><span>Sunday</span><span className="badge-closed">Closed</span></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-7 fade-up">
              <div className="rounded-xl overflow-hidden" style={{ height: 400, boxShadow: "var(--shadow-sm)" }}>
                <iframe
                  src={CLINIC.mapEmbedHome}
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="We Care Medical Zone Location"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

import PageHero from "@/components/PageHero";
import { CLINIC, TREATMENTS } from "@/lib/data";

export const metadata = {
  title: "Women's Health Treatments | PCOD, Infertility, Pregnancy",
  description:
    "Detailed information on PCOD, infertility, pregnancy care, menstrual problems, menopause, fibroid and ovarian cyst treatments at We Care Medical Zone by Dr. Salama Hanif.",
};

export default function TreatmentsPage() {
  return (
    <>
      <PageHero
        current="Treatments"
        title="Women's Health Treatments"
        subtitle="In-depth information about the conditions we treat and our approach to healing."
      />

      <section className="section-pad">
        <div className="container">
          <div className="row g-5">
            <div className="col-lg-8">
              <div className="accordion" id="treatmentAccordion">
                {TREATMENTS.map((t) => (
                  <div className="accordion-item" key={t.id}>
                    <h2 className="accordion-header">
                      <button
                        className={`accordion-button${t.open ? "" : " collapsed"}`}
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target={`#${t.id}`}
                      >
                        <i className={`bi ${t.icon} text-pink me-3 fs-5`} /> {t.title}
                      </button>
                    </h2>
                    <div
                      id={t.id}
                      className={`accordion-collapse collapse${t.open ? " show" : ""}`}
                      data-bs-parent="#treatmentAccordion"
                    >
                      <div className="accordion-body">
                        <p>{t.intro}</p>
                        {t.list && (
                          <>
                            <h6 className="fw-600 mb-2">{t.listTitle}</h6>
                            <ul className="text-muted" style={{ fontSize: ".9rem" }}>
                              {t.list.map((li) => (
                                <li key={li}>{li}</li>
                              ))}
                            </ul>
                          </>
                        )}
                        {t.approach && (
                          <>
                            <h6 className="fw-600 mb-2 mt-3">{t.approachTitle}</h6>
                            <p style={{ fontSize: ".9rem" }} className="text-muted">{t.approach}</p>
                          </>
                        )}
                        <a
                          href="#"
                          data-bs-toggle="modal"
                          data-bs-target="#apptModal"
                          className="btn-pink btn mt-2"
                        >
                          Book Consultation <i className="bi bi-arrow-right ms-2" />
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* SIDEBAR */}
            <div className="col-lg-4">
              <div className="contact-card mb-4 fade-up">
                <h5 className="mb-3">Book a Consultation</h5>
                <p className="text-muted" style={{ fontSize: ".87rem" }}>
                  Get expert diagnosis and personalized treatment from {CLINIC.doctor}.
                </p>
                <a
                  href="#"
                  data-bs-toggle="modal"
                  data-bs-target="#apptModal"
                  className="btn-pink btn w-100 mb-3"
                >
                  <i className="bi bi-calendar-plus me-2" />
                  Book Appointment
                </a>
                <a href={`tel:${CLINIC.phone}`} className="btn-outline-pink btn w-100">
                  <i className="bi bi-telephone me-2" />
                  Call: {CLINIC.phone}
                </a>
                <div className="mt-4 pt-3" style={{ borderTop: "1px solid var(--grey-border)" }}>
                  <div className="timing-row"><span style={{ fontSize: ".85rem" }}>Morning</span><span style={{ fontSize: ".85rem" }}>9 AM – 12 PM</span></div>
                  <div className="timing-row"><span style={{ fontSize: ".85rem" }}>Evening</span><span style={{ fontSize: ".85rem" }}>6 PM – 9 PM</span></div>
                  <div className="timing-row"><span style={{ fontSize: ".85rem" }}>Friday</span><span className="badge-closed">Closed</span></div>
                </div>
              </div>
              <div style={{ background: "var(--pink-light)", borderRadius: 14, padding: 24 }} className="fade-up">
                <h6 className="text-pink mb-3"><i className="bi bi-gift-fill me-2" />New Patient Offers</h6>
                <div className="d-flex align-items-center gap-2 mb-2"><i className="bi bi-check-circle-fill text-pink" /><span style={{ fontSize: ".88rem" }}>50% off first consultation</span></div>
                <div className="d-flex align-items-center gap-2 mb-2"><i className="bi bi-check-circle-fill text-pink" /><span style={{ fontSize: ".88rem" }}>15% off on medicines</span></div>
                <div className="d-flex align-items-center gap-2"><i className="bi bi-check-circle-fill text-pink" /><span style={{ fontSize: ".88rem" }}>30% off on lab tests</span></div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

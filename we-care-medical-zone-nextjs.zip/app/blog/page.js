import PageHero from "@/components/PageHero";
import { BLOG_POSTS, CLINIC } from "@/lib/data";

export const metadata = {
  title: "Women's Health Blog | PCOD, Pregnancy, Hygiene Tips",
  description:
    "Read expert articles on PCOD, pregnancy care, women's hygiene and menstrual health by Dr. Salama Hanif at We Care Medical Zone, Raebareli.",
};

export default function BlogPage() {
  return (
    <>
      <PageHero
        current="Blog"
        title="Women's Health Blog"
        subtitle={`Expert health articles and tips from ${CLINIC.doctor} to help you live a healthier life.`}
      />

      <section className="section-pad">
        <div className="container">
          <div className="row g-4">
            {BLOG_POSTS.map((post) => (
              <div className="col-md-6 col-lg-6 fade-up" key={post.title}>
                <div className="blog-card">
                  <div className="blog-img" style={{ background: post.gradient }}>
                    <span>{post.emoji}</span>
                  </div>
                  <div className="blog-body">
                    <span className="blog-tag">{post.tag}</span>
                    <h5>{post.title}</h5>
                    <p className="text-muted" style={{ fontSize: ".88rem", marginBottom: 16 }}>{post.excerpt}</p>
                    <div className="d-flex align-items-center justify-content-between">
                      <div className="blog-meta">
                        <i className="bi bi-person-circle me-1" />
                        {CLINIC.doctor} &nbsp;|&nbsp; <i className="bi bi-calendar3 me-1" />
                        {post.date}
                      </div>
                      <a href="#" className="read-more">
                        Read More <i className="bi bi-arrow-right" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Newsletter CTA */}
          <div
            className="mt-5 p-4 p-md-5 rounded-2xl fade-up"
            style={{ background: "linear-gradient(135deg,var(--pink-light),var(--blue-light))", border: "1.5px solid var(--grey-border)" }}
          >
            <div className="row align-items-center gy-3">
              <div className="col-md-7">
                <h4 style={{ marginBottom: 8 }}>Stay Updated on Women&apos;s Health</h4>
                <p className="text-muted mb-0" style={{ fontSize: ".9rem" }}>
                  Get expert health tips, clinic updates and exclusive offers from{" "}
                  {CLINIC.doctor}&apos;s clinic delivered to your phone.
                </p>
              </div>
              <div className="col-md-5">
                <div className="d-flex gap-2">
                  <input type="tel" className="form-control" placeholder="Your Phone Number" />
                  <button className="btn-pink btn" style={{ whiteSpace: "nowrap" }}>Subscribe</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

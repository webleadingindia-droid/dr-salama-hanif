"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { NAV_LINKS } from "@/lib/data";

export default function Navbar() {
  const pathname = usePathname();

  return (
    <nav className="navbar navbar-expand-lg sticky-top" id="mainNav">
      <div className="container">
        <Link className="navbar-brand d-flex align-items-center gap-2" href="/">
          <div className="brand-icon">
            <i className="bi bi-heart-pulse-fill text-white" />
          </div>
          <div>
            <span>We Care</span> <span className="text-pink">Medical Zone</span>
          </div>
        </Link>

        <button
          className="navbar-toggler border-0"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navMenu"
          aria-controls="navMenu"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <i className="bi bi-list fs-4 text-pink" />
        </button>

        <div className="collapse navbar-collapse" id="navMenu">
          <ul className="navbar-nav ms-auto align-items-lg-center gap-1">
            {NAV_LINKS.map((link) => (
              <li className="nav-item" key={link.href}>
                <Link
                  className={`nav-link${pathname === link.href ? " active" : ""}`}
                  href={link.href}
                >
                  {link.label}
                </Link>
              </li>
            ))}
            <li className="nav-item ms-lg-2">
              <a
                className="nav-link nav-book"
                href="#"
                data-bs-toggle="modal"
                data-bs-target="#apptModal"
              >
                <i className="bi bi-calendar-check me-1" />
                Book Appointment
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}

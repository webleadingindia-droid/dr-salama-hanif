"use client";

import { useEffect, useRef, useState } from "react";
import { TREATMENT_OPTIONS } from "@/lib/data";

export default function AppointmentModal() {
  const [status, setStatus] = useState("idle"); // idle | submitting | success
  const modalRef = useRef(null);

  function handleSubmit(e) {
    e.preventDefault();
    setStatus("submitting");
    setTimeout(() => {
      setStatus("success");
    }, 1500);
  }

  useEffect(() => {
    const el = modalRef.current;
    if (!el) return;
    // Reset the form back to idle once the modal has fully closed,
    // using Bootstrap's own modal lifecycle event.
    const onHidden = () => setStatus("idle");
    el.addEventListener("hidden.bs.modal", onHidden);
    return () => el.removeEventListener("hidden.bs.modal", onHidden);
  }, []);

  return (
    <div
      className="modal fade"
      id="apptModal"
      ref={modalRef}
      tabIndex={-1}
      aria-labelledby="apptModalLabel"
      aria-hidden="true"
    >
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title" id="apptModalLabel">
              <i className="bi bi-calendar-heart me-2" />
              Book Your Ayurvedic Appointment
            </h5>
            <button
              type="button"
              className="btn-close btn-close-white"
              data-bs-dismiss="modal"
              aria-label="Close"
            />
          </div>
          <div className="modal-body">
            <form id="appointmentForm" onSubmit={handleSubmit}>
              {status === "success" ? (
                <div className="text-center py-4">
                  <div
                    style={{
                      width: 70,
                      height: 70,
                      background: "var(--pink-light)",
                      borderRadius: "50%",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      margin: "0 auto 20px",
                      fontSize: "2rem",
                      color: "var(--pink)",
                    }}
                  >
                    <i className="bi bi-check-circle-fill" />
                  </div>
                  <h5 style={{ color: "var(--text-dark)" }}>Appointment Request Sent!</h5>
                  <p className="text-muted">
                    Your Ayurvedic appointment request has been received. Our team will contact
                    you shortly.
                  </p>
                  <button type="button" className="btn-outline-pink btn" data-bs-dismiss="modal">
                    Close
                  </button>
                </div>
              ) : (
                <div id="apptFormFields">
                  <div className="mb-3">
                    <label className="form-label">Patient Name *</label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Enter your full name"
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Phone Number *</label>
                    <input
                      type="tel"
                      className="form-control"
                      placeholder="Enter your phone number"
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Problem / Treatment *</label>
                    <select className="form-select" required defaultValue="">
                      <option value="">Select Ayurvedic treatment needed</option>
                      {TREATMENT_OPTIONS.map((opt) => (
                        <option key={opt}>{opt}</option>
                      ))}
                    </select>
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Preferred Date</label>
                    <input type="date" className="form-control" />
                  </div>
                  <div className="mb-4">
                    <label className="form-label">Message (Optional)</label>
                    <textarea
                      className="form-control"
                      rows={3}
                      placeholder="Describe your symptoms briefly…"
                    />
                  </div>
                  <button
                    type="submit"
                    className="btn-pink btn w-100"
                    disabled={status === "submitting"}
                  >
                    {status === "submitting" ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" />
                        Submitting…
                      </>
                    ) : (
                      <>
                        <i className="bi bi-calendar-check me-2" />
                        Book Ayurvedic Appointment
                      </>
                    )}
                  </button>
                  <p className="text-center text-muted mt-3" style={{ fontSize: ".78rem" }}>
                    🎉 50% off on your first Ayurvedic consultation
                  </p>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
